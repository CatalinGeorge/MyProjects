Admin panel
<?php echo $user['us_email']; ?>
