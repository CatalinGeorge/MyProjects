Edit users
<br>
<ul><?php foreach($users as $us): ?>
  <li>
    <?php echo $us['us_first']; ?>
  <?php echo $us['us_last']; ?>
  <a href="<?php echo base_url(); ?>admin/edit_user/<?php echo $us['us_id']; ?>">Edit</a>
<a href="<?php echo base_url(); ?>admin/delete_user/<?php echo $us['us_id']; ?>">Delete</a>
<a href="<?php echo base_url(); ?>admin/user_networks/<?php echo $us['us_id']; ?>">User's networks</a>
<a href="<?php echo base_url(); ?>admin/add_network_details/<?php echo $us['us_id']; ?>">Add network</a>
<?php if($us['us_set_pop'] === '0'){ ?>
<a href="<?php echo base_url(); ?>admin/set_popularity/<?php echo $us['us_id']; ?>">Set popularity</a>
<?php }else { ?>
<a href="<?php echo base_url(); ?>admin/unset_popularity/<?php echo $us['us_id']; ?>">Unset popularity</a>
<?php  } ?>


<?php if($us['us_set_block'] === '0'){ ?>
<a href="<?php echo base_url(); ?>admin/block/<?php echo $us['us_id']; ?>">Block user </a>
<?php }else { ?>
<a href="<?php echo base_url(); ?>admin/unblock/<?php echo $us['us_id']; ?>">Unblock user </a>
<?php  } ?>










<?php endforeach; ?>
</ul>
