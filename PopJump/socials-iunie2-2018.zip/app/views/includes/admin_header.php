<html>
<head>

  <meta name="viewport" content="width=device-width, user-scalable=no">
  <!-- CSS -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">

  <!-- Lainside-categ compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <!-- AngularJS -->
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

  <!-- Lainside-categ compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <!-- Font -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

  <script src="<?php echo base_url(); ?>assets/js/angular.js"></script>


</head>

<body ng-app="socialsApp" ng-controller="mainCtrl">

        <div class="row">
          <div class="col-md-6 text-right p0">
            <a class="inline text-white menu-color plr10" href="<?php echo base_url(); ?>admin/admin_panel">Home</a>
            <a class="inline text-white menu-color plr10" href="<?php echo base_url(); ?>admin/go/users">Users</a>
            <a class="inline text-white menu-color plr10" href="<?php echo base_url(); ?>home">Home Website</a>
            

          </div>
        </div>
