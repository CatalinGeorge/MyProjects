<?php

class AdminBBCarrierCarrierMasterController extends ModuleAdminController
{
    public function __construct ()
    {
        $this->bootstrap = true;
        $this->table = 'bbcarrier';
        $this->className = 'AdminBBCarrierCarrierMaster';
        $this->lang = false;
        $this->context = Context::getContext();

        parent::__construct();
    }

    public function renderList ()
    {
        return parent::renderList();
    }
}
