<?php

require_once _PS_MODULE_DIR_ . 'bbcarrier/classes/BBCarrierCarrier.php';
require_once _PS_MODULE_DIR_ . 'bbcarrier/classes/BBCarrierCarrierMaster.php';

class AdminBBCarrierController extends ModuleAdminController
{
    public function __construct ()
    {
        $this->bootstrap = true;
        $this->table = BBCarrierCarrierMaster::$definition["table"];
        $this->className = 'BBCarrierCarrierMaster';
        $this->lang = false;
        $this->context = Context::getContext();

        parent::__construct();

        $this->fields_list = array(
            'id_bbcarrier_carrier_master' => array(
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'type' => 'int',
            ),
            'name' => array(
                'title' => $this->l('Name'),
            ),
            'cost_increment' => array(
                'title' => $this->l('Cost incremet (%)'),
                'type' => 'int',
                'align' => 'text-right',
            ),
            'active' => array(
                'title' => $this->l('Status'),
                'active' => 'status',
                'type' => 'bool',
                'class' => 'fixed-width-xs',
                'align' => 'center',
                'orderby' => false,
                'search' => false
            )
        );
    }

    public function initContent ($token = null)
    {
        // Formulario de configuración del modulo
        if (Tools::isSubmit('saveSKUPrefix')) {
            $skuPrefix = Tools::getValue('sku_prefix');

            // Saving new sku prefix configurations
            if (Configuration::updateValue('BBCARRIER_SKU_PREFIX', $skuPrefix)) {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayConfirmation($this->l('SKU prefix updated!'));
            }
            else {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayError($this->l('Settings failed'));
            }
        }
		
		// Formulario de configuración del modulo
        if (Tools::isSubmit('saveCarrierMasterIncrement')) {
            $carrierMaster = new BBCarrierCarrierMaster(Tools::getValue('id_bbcarrier_carrier_master'));

            $carrierMaster->cost_increment = Tools::getValue('cost_increment');

            // Saving new carrier configurations
            if ($carrierMaster->update()) {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayConfirmation($this->l('Settings updated'));
            }
            else {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayError($this->l('Settings failed'));
            }
        }
        
        // Formulario de configuración del modulo
        if (Tools::isSubmit('saveCarrierMasterEdit')) {
            $carrierMaster = new BBCarrierCarrierMaster(Tools::getValue('id_bbcarrier_carrier_master'));
            $carrierMaster->active = Tools::getValue('active');
            $carrierMaster->cost_increment = Tools::getValue('cost_increment');

            // Saving new carrier configurations
            if ($carrierMaster->update()) {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayConfirmation($this->l('Settings updated'));
            }
            else {
                $this->content .= Module::getInstanceByName('bbcarrier')->displayError($this->l('Settings failed'));
            }
        }

        // Desactivación de carriers
        if (Tools::isSubmit('submitBulkdisablebbcarrier_carrier_master')) {
            $this->disableMasterCarriers(Tools::getValue('bbcarrier_carrier_masterBox'));
        }

        // Activación de carriers
        if (Tools::isSubmit('submitBulkenablebbcarrier_carrier_master')) {
            $this->enableMasterCarriers(Tools::getValue('bbcarrier_carrier_masterBox'));
        }

        // Cambia el carrier de activado a desactivado y vice-versa.
        if (Tools::isSubmit('conf') && Tools::getValue('conf') == 5) {
            $this->toggleStatusMasterCarrier(Tools::getValue('id_bbcarrier_carrier_master'));
        }
        
        if (!Tools::isSubmit("updatebbcarrier_carrier_master")) {
            $this->content .= $this->renderForm();
        }

        parent::initContent();
    }

    private function toggleStatusMasterCarrier ($carrierMasterId)
    {
        $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
        
        switch ($carrierMaster->active) {
            case 0:
                return $this->enableMasterCarriers(array($carrierMasterId));
            case 1:
                return $this->disableMasterCarriers(array($carrierMasterId));
        }
    }

    private function disableMasterCarriers ($carrierMasterIds)
    {
        if (!$carrierMasterIds) {
            return;
        }

        foreach ($carrierMasterIds as $carrierMasterId) {
            $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
            $carrierMaster->active = 0;
            $carrierMaster->update();

            $moduleCarriers = BBCarrierCarrier::getCarriersByCarrierMasterId($carrierMasterId, true);

            foreach ($moduleCarriers as $moduleCarrier) {
                BBCarrierCarrier::removeCarrier(
                    $moduleCarrier[BBCarrierCarrier::$definition["primary"]], 
                    $moduleCarrier["id_carrier"]
                );
            }
        }
    }

    private function enableMasterCarriers ($carrierMasterIds)
    {
        if (!$carrierMasterIds) {
            return;
        }

        foreach ($carrierMasterIds as $carrierMasterId) {
            $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
            $carrierMaster->active = 1;
            $carrierMaster->update();

            $moduleCarriers = BBCarrierCarrier::getCarriersByCarrierMasterId($carrierMasterId);

            foreach ($moduleCarriers as $moduleCarrier) {
                BBCarrierCarrier::enableCarrier(
                    $moduleCarrier[BBCarrierCarrier::$definition["primary"]], 
                    $moduleCarrier["id_carrier"]
                );
            }
        }
    }

    /**
     * El formulario de la pestaña de configuración del módulo
     */
    public function renderForm ()
    {
        $content = $this->renderSkuPrefixForm();
        $content .= $this->renderCarrierForm();
		
        return $content;
    }
    
    private function renderSkuPrefixForm () 
    {
        $defaultLang = (int) Configuration::get('PS_LANG_DEFAULT');
        $fieldsForm = $this->getSKUPrefixFields();
		
        $helper = new HelperForm();
        $helper->module = Module::getInstanceByName('bbcarrier');
        $helper->name_controller = 'AdminBBCarrier';
        $helper->identifier = BBCarrierCarrierMaster::$definition["table"] . "SKUPrefix";
        $helper->token = Tools::getAdminTokenLite('AdminBBCarrier');

        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($defaultLang == $lang['id_lang'] ? 1 : 0)
            );
        }

		$skuPrefix = $this->getSkuPrefix();
		
        $helper->currentIndex = AdminController::$currentIndex;
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'saveSKUPrefix';
        $helper->fields_value = array(
            "sku_prefix" => $skuPrefix,
        );

        return $helper->generateForm(array(array('form' => $fieldsForm)));
    }
	
	private function getSkuPrefix () 
	{
		$skuPrefix = Configuration::get('BBCARRIER_SKU_PREFIX');
		
		if (!$skuPrefix) {
			$skuPrefix = "bb_";
			Configuration::updateValue('BBCARRIER_SKU_PREFIX', $skuPrefix);
		}
		
		return $skuPrefix;
	}
	
    private function getSKUPrefixFields()
    {
        return $fieldsForm = array(
            'legend' => array(
                'title' => $this->l('SKU Prefix'),
                'icon' => 'icon-cogs'
            ),
            'input' => array(
                array(
                    'type' => 'text', // This is a regular <input> tag.
                    'label' => $this->l('SKU Prefix'), // The <label> for this <input> tag.
                    'name' => 'sku_prefix', // The content of the 'id' attribute of the <input> tag.
                    'class' => 'sm fixed-width-xl', // The content of the 'class' attribute of the <input> tag. To set the size of the element, use these: sm, md, lg, xl, or xxl.
                    'default_value' => '0',
                    'required' => true, // If set to true, this option must be set.
                    'desc' => $this->l('Insert the custom prefix added to all BigBuy references.') // A help text, displayed right next to the <input> tag.
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            )
        );
    }
	
    private function renderCarrierForm () 
    {
        if (Tools::isSubmit("updatebbcarrier_carrier_master")) {
            $fieldsForm = $this->renderCarrierMasterForm ();
        }
        else {
            $fieldsForm = $this->renderConfigurationForm();
        }
        
        $defaultLang = (int) Configuration::get('PS_LANG_DEFAULT');

        $helper = new HelperForm();
        $helper->module = Module::getInstanceByName('bbcarrier');
        $helper->name_controller = 'AdminBBCarrier';
        $helper->identifier = BBCarrierCarrierMaster::$definition["table"] . "CostIncrement";
        $helper->token = Tools::getAdminTokenLite('AdminBBCarrier');

        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($defaultLang == $lang['id_lang'] ? 1 : 0)
            );
        }

        $helper->currentIndex = AdminController::$currentIndex;
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;
        $helper->toolbar_scroll = true;
        
        if (Tools::isSubmit("updatebbcarrier_carrier_master")) {
            $helper->submit_action = 'saveCarrierMasterEdit';
            $carrierMasterId = Tools::getValue("id_bbcarrier_carrier_master");
            $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
            $fieldsForm["legend"]["title"] .= $carrierMaster->name;
            $helper->fields_value = array(
                "cost_increment" => $carrierMaster->cost_increment,
                "active" => $carrierMaster->active,
                "id_bbcarrier_carrier_master" => $carrierMaster->id,
            );
        }
        else {
            $helper->submit_action = 'saveCarrierMasterIncrement';
            $helper->fields_value = array(
                "cost_increment" => "0",
                "id_bbcarrier_carrier_master" => "1",
            );
        }

        return $helper->generateForm(array(array('form' => $fieldsForm)));
	}
	
    private function renderConfigurationForm()
    {
        return $fieldsForm = array(
            'legend' => array(
                'title' => $this->l('Carrier cost increment'),
                'icon' => 'icon-cogs'
            ),
            'input' => array(
                array(
                    'type' => 'text', // This is a regular <input> tag.
                    'label' => $this->l('Cost increment'), // The <label> for this <input> tag.
                    'name' => 'cost_increment', // The content of the 'id' attribute of the <input> tag.
                    'class' => 'sm fixed-width-xl', // The content of the 'class' attribute of the <input> tag. To set the size of the element, use these: sm, md, lg, xl, or xxl.
                    'default_value' => '0',
                    'required' => true, // If set to true, this option must be set.
                    'suffix' => '%',
                    'desc' => $this->l('Insert the percentage of cost increment.') // A help text, displayed right next to the <input> tag.
                ),
                array(
                    'type' => 'select', // This is a regular <input> tag.
                    'label' => $this->l('Carrier'), // The <label> for this <input> tag.
                    'name' => 'id_bbcarrier_carrier_master', // The content of the 'id' attribute of the <input> tag.
                    'options' => array(// This is only useful if type == select
                        'query' => BBCarrierCarrierMaster::getCarrierMasters(), // $array_of_rows must contain an array of arrays, inner arrays (rows) being mode of many fields   
                        'id' => 'id_bbcarrier_carrier_master',
                        'name' => 'name' // The key that will be used for each option "value" attribute
                    ),
                    'class' => 'sm fixed-width-xl', // The content of the 'class' attribute of the <input> tag. To set the size of the element, use these: sm, md, lg, xl, or xxl.
                    'desc' => $this->l('Select the carrier to which to apply the increment.') // A help text, displayed right next to the <input> tag.
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            )
        );
    }
    
    private function renderCarrierMasterForm()
    {
        return $fieldsForm = array(
            'legend' => array(
                'title' => $this->l('Carrier edit: '),
                'icon' => 'icon-truck'
            ),
            'input' => array(
                array(
                    'type' => 'hidden', // This is a regular <input> tag.
                    'name' => 'id_bbcarrier_carrier_master', // The content of the 'id' attribute of the <input> tag.
                ),
                array(
                    'type' => 'text', // This is a regular <input> tag.
                    'label' => $this->l('Cost increment'), // The <label> for this <input> tag.
                    'name' => 'cost_increment', // The content of the 'id' attribute of the <input> tag.
                    'class' => 'sm fixed-width-xl', // The content of the 'class' attribute of the <input> tag. To set the size of the element, use these: sm, md, lg, xl, or xxl.
                    'default_value' => '0',
                    'required' => true, // If set to true, this option must be set.
                    'suffix' => '%',
                    'desc' => $this->l('Insert the percentage of cost increment.') // A help text, displayed right next to the <input> tag.
                ),
                array(
                    'type' => 'switch', // This is a regular <input> tag.
                    'label' => $this->l('Status'), // The <label> for this <input> tag.
                    'name' => 'active', // The content of the 'id' attribute of the <input> tag.
                    'desc' => $this->l('Activate/Deactivate the carrier'), // A help text, displayed right next to the <input> tag.
                    'required' => true, // If set to true, this option must be set.
                    'is_bool' => true, // If set to true, this means you want to display a yes/no or true/false option.
                    'values' => array(// $values contains the data itself.
                        array(
                            'id' => 'active_on', // The content of the 'id' attribute of the <input> tag, and of the 'for' attribute for the <label> tag.
                            'value' => 1, // The content of the 'value' attribute of the <input> tag.   
                            'label' => $this->l('Enabled')                    // The <label> for this radio button.
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    ),
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            )
        );
    }

    public function setHelperDisplay (Helper $helper)
    {
        parent::setHelperDisplay($helper);
        $helper->toolbar_btn = array ("AdminBBCarrier" => null);
        $helper->icon = "icon-truck";
        $helper->title = "BigBuy Carriers";
    }

    /**
     * Gestiona la acción de listado de entidades 
     */
    public function renderList ()
    {
        $this->addRowAction("edit");
        return parent::renderList();
    }
    
    /**
     * Change object status (active, inactive)
     *
     * @return ObjectModel|false
     * @throws PrestaShopException
     */
    public function processStatus()
    {
        if (Validate::isLoadedObject($object = $this->loadObject())) {
            $this->toggleStatusMasterCarrier($object->id);
        }
    }
}
