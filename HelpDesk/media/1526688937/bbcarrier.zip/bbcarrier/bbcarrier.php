<?php

// Version 1.4
// Avoid direct access to the file
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once _PS_MODULE_DIR_.'bbcarrier/classes/BBCarrierAPI.php';
require_once _PS_MODULE_DIR_.'bbcarrier/classes/BBCarrierCarrier.php';
require_once _PS_MODULE_DIR_.'bbcarrier/classes/BBCarrierCarrierMaster.php';

class bbcarrier extends CarrierModule
{
    public $id_carrier;

    private $navTabs = array(
        array(
            'className' => 'AdminBBCarrierCarrierMaster',
            'title' => 'BigBuy Carriers',
            'name' => array(
                '4' => 'BigBuy Carriers', // Nombre por idioma (id_lang => nombre)
            ),
            'active' => 1,
            'children' => array(
                array(
                    'className' => 'AdminBBCarrier', // Nombre del controlador AdminMiModuloPruebaAController
                    'title' => 'Carriers',
                    'name' => array(
                        '4' => 'Carriers', // Nombre por idioma (id_lang => nombre)
                    ),
                    'position' => 1,
                    'active' => 1,
                ),
            ),
        ),
    );
    
    /**
     * Construct Method
     */
    public function __construct ()
    {
        $this->bootstrap = true;
        $this->tab = 'shipping_logistics';
        $this->author = 'BigBuy';
        $this->name = "bbcarrier";
        $this->version = '2.3.1';
        
        parent::__construct();
       
        $this->displayName = $this->l('BigBuy carrier configurator');
        $this->description = $this->l('Módulo que integra el sistema de envíos de varios transportistas.');
    }

    /**
     * Instalación del modulo
     * 
     * MIA : Crear un carrier para cada tipo de servicio que ofrece
     */
    public function install ()
    {
        $this->installSQL();
        //Inicializamos la fecha de última actualización al día de instalación
        $firstUpdate = new DateTime("now");
        // Creamos las tablas del modulo
        $this->cleanTabs();
        //Creamos e instalamos los transportistas
        $this->installTabs();
        // Limpiamos los carriers de instalaciones anteriores
        $this->cleanModuleDeletedCarriers();
        //Creamos e instalamos los transportistas
        
        //Instalamos el modulo
        if (!parent::install() 
            || !BBCarrierCarrierMaster::createCarriers()
            || !$this->registerHook('updateCarrier')
            || !$this->registerHook('displayFooter')
            || !$this->registerHook('displayBackOfficeHeader')) {
            return false;
        }

        //Creamos la variable de última actualización de la API
        Configuration::updateValue('BBCARRIER_LAST_API_UPDATE', $firstUpdate->format("Y-m-d H:i:s"));
        Configuration::updateValue('BBCARRIER_SKU_PREFIX', "bb_");
        
        return true;
    }

    // Uninstall
    public function uninstall ()
    {
        if (!parent::uninstall() 
            || !$this->unregisterHook('updateCarrier')
            || !$this->unregisterHook('displayFooter')
            || !$this->unregisterHook('displayBackOfficeHeader')) {
            return false;
        }

        $this->uninstallTabs();
        BBCarrierCarrier::removeCarriers();
        
        // Limpiamos los carriers de instalaciones anteriores
        $this->cleanModuleDeletedCarriers();
        
        // Eliminamos las variables de configuración del modulo
        Configuration::deleteByName('BBCARRIER_LAST_API_UPDATE');

        $this->uninstallSQL();
        
        return true;
    }
    
    public function setBigBuyRoot () 
    {
        $tabBigBuyName = "BigBuy";
        $tabBigBuyClassName = "AdminBBRoot";
        $tabBigBuyModuleName = "BBRoot";
        $tabBigBuyRoot = Tab::getIdFromClassName("AdminBBRoot");
        
        if ($tabBigBuyRoot) {
            return $tabBigBuyRoot;
        }
        else {
            $tabBigBuyRoot = new Tab();
            $tabBigBuyRoot->active = true;
            $tabBigBuyRoot->class_name = $tabBigBuyClassName;
            $tabBigBuyRoot->module = $tabBigBuyModuleName;
            
             foreach (Language::getLanguages(true) as $lang) {
                $tabBigBuyRoot->name[$lang['id_lang']] = $tabBigBuyName;
            }
            $tabBigBuyRoot->id_parent = 0;
            
            $tabBigBuyRoot->add();
            
            return $tabBigBuyRoot->id;
        }
    }
    
    public function installTabs ($navTabs = null, $padre = 0)
    {
        if (!$navTabs) {
            $navTabs = $this->navTabs;
        }

        foreach ($navTabs as $navTab) {
            $tab_padre = new Tab();
            $tab_padre->active = $navTab['active'];
            $tab_padre->class_name = $navTab['className'];
            $tab_padre->name = array();
            
            foreach (Language::getLanguages(true) as $lang) {
                $name = $this->getNavName($navTab, $lang['id_lang']);
                $tab_padre->name[$lang['id_lang']] = $name;
            }
            
            if ($padre === 0) {
                $tab_padre->id_parent = $this->setBigBuyRoot ();
            }
            else {
                $tab_padre->id_parent = (int) $padre;
            }
            
            $tab_padre->module = $this->name;
            $tab_padre->add();
            
            if (isset($navTab['children'])) {
                $this->installTabs($navTab['children'], $tab_padre->id);
            }
        }
    }
    
    private function getNavName ($navTab, $idLang)
    {
        if (isset($navTab['name'])) {
            if (isset($navTab['name'][$idLang])) { // Devuleve el nombre para el idioma definido, si existe
                return $navTab['name'][$idLang];
            } 
            else { // Devolvemos el primer nombre disponible
                foreach ($navTab['name'] as $key => $value) {
                    return $value;
                }
            }
        }
        
        // Devuelve el titulo si el nombre no esta definido
        return $navTab['title']; 
    }
    
    private function cleanModuleDeletedCarriers()
    {
        DB::getInstance()->update(
            "carrier", 
            array("active" => 0, "deleted" => 1), 
            "external_module_name = '" . $this->name . "'"
        );
    }
    
    public function cleanTabs ()
    {
        $id_lang = Context::getContext()->language->id;
        $navTabs = new PrestaShopCollection('Tab', (int) $id_lang);
        $navTabs->where('module', '=', $this->name);
        
        foreach ($navTabs as $navTab) {
            $navTab->delete(); // La eliminamos
        }
    }

    public function uninstallTabs ($navTabs = null)
    {
        if (!$navTabs) {
            $navTabs = $this->navTabs;
        }

        foreach ($navTabs as $navTab) {
            $id_tab = (int) Tab::getIdFromClassName($navTab['className']); // Buscamos la ficha con el nombre conficurado

            if ($id_tab !== 0) { // Si existe
                if (isset($navTab['children'])) { // Si tiene hijos, los desinstalamos
                    $this->uninstallTabs($navTab['children']);
                }
                $tab_to = new Tab($id_tab); // Recuperamos la ficha
                $tab_to->delete(); // La eliminamos
            }
        }
    }
    
    private function installSQL()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'bbcarrier_carrier_master` (
                    `id_bbcarrier_carrier_master` int(10) unsigned NOT NULL,
                    `name` varchar(50) NOT NULL,
                    `cost_increment` FLOAT NULL DEFAULT 0,
                    `active` TINYINT(1) unsigned NOT NULL,
                    PRIMARY KEY (`id_bbcarrier_carrier_master`),
                    INDEX `bbcarrier_carrier_master_name` (`name`)
                )
                COLLATE="utf8_general_ci"
                ENGINE=' . _MYSQL_ENGINE_ . ';';
        
        $sql .= 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'bbcarrier_carrier` (
                    `id_bbcarrier_carrier` int(10) unsigned NOT NULL,
                    `name` varchar(250) NOT NULL,
                    `id_carrier` int(10) unsigned NOT NULL,
                    `id_bbcarrier_carrier_master` int(10) unsigned NOT NULL,
                    `active` TINYINT(1) unsigned NOT NULL,
                    PRIMARY KEY (`id_bbcarrier_carrier`),
                    INDEX `bbcarrier_carrier__id_carrier` (`id_carrier`),
                    INDEX `bbcarrier_carrier__id_bbcarrier_carrier_master` (`id_bbcarrier_carrier_master`)
                )
                COLLATE="utf8_general_ci"
                ENGINE=' . _MYSQL_ENGINE_ . ';';

        return Db::getInstance()->execute($sql);
    }

    private function uninstallSQL()
    {
        $sql = 'SET FOREIGN_KEY_CHECKS = 0;';
        $sql .= 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'bbcarrier_carrier`;';
        $sql .= 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'bbcarrier_carrier_master`;';
        $sql .= 'SET FOREIGN_KEY_CHECKS = 1;';
        
        return Db::getInstance()->execute($sql);
    }
    
    /**
     * El contenido de la pestaña de configuración del módulo
     */
    public function getContent ()
    {
         Tools::redirectAdmin($this->context->link->getAdminLink('AdminBBCarrier'));
    }

    /**
     * Hook update carrier
     */
    public function hookUpdateCarrier ($params)
    {
        $moduleCarrier = BBCarrierCarrier::getCarrierByCarrierId($params['id_carrier']);
        
        if ($moduleCarrier && $params['id_carrier'] == $moduleCarrier["id_carrier"]) {
            $carrier = new BBCarrierCarrier((int)$moduleCarrier[BBCarrierCarrier::$definition["primary"]]);
            $carrier->force_id;
            $carrier->id_carrier = $params['carrier']->id;
            $carrier->update();
        }
    }

    /**
     * Hook display footer
     */
    public function hookDisplayFooter ($params)
    {
        BBCarrierCarrierMaster::updateCarriersByAPI();
    }
    
    /**
     * Hook display backend header
     * 
     * Adds BBRoot admin tab CSS.
     */
    public function hookDisplayBackOfficeHeader ()
    {
        $controller = $this->context->controller;
        
        if (method_exists($controller, 'addCss')) {
            $controller->addCss($this->_path . 'css/styles.css');
        }
    }

    public function getOrderShippingCostExternal ($params)
    {
        
    }
    
    /**
     * @deprecated 1.5.0, use Cart->getPackageShippingCost()
     * 
     * $cart var contains the cart, the customer, the address
     * $shipping_cost var contains the price calculated by the range in carrier tab
     */
    public function getOrderShippingCost ($cart, $shippingCost)
    {
        return $this->getPackageShippingCost($cart, $shippingCost, $cart->getProducts());
    }
    
    /**
     * Calcula el coste de envío para el transportista del modulo.
     * 
     * En cada petición de gastos de envío, Actualiza los datos de los 
     * transportistas del modulo.
     * Si el usuario no esté logeado o no dispone de una dirección de entrega, no
     * devuelve el carrier.
     * 
     * @param type $cart el carrito
     * @param type $cartShippingCost el coste de envío calculado en el carrito
     * @param type $products el listado de productos del carrito
     * 
     * @return float|false el coste de envío o false en caso de que el 
     *                      transportista no se aplique al carrito
     */
    public function getPackageShippingCost ($cart, $cartShippingCost, $products)
    {
        $shippingCost = false;
        
        if (!Customer::customerHasAddress($cart->id_customer, $cart->id_address_delivery)) {
            return $shippingCost;
        }
        
        BBCarrierCarrierMaster::updateCarriersByAPI();

        // Obtenemos las opciones de envío de la API
        $shippingOptions = $this->getShippingOptions($cart, $products);
        
        // Obtenemos los transportistas instalados por el modulo
        $moduleCarrier = BBCarrierCarrier::getCarrierByCarrierId($this->id_carrier);
        
        if (!$moduleCarrier) {
            return $shippingCost;
        }
        
        $moduleCarrierId = $moduleCarrier[BBCarrierCarrier::$definition["primary"]];
        //Obtenemos tarifas de base de datos
        
        $shippingRate = $this->getShippingRate($shippingOptions, $moduleCarrierId);

        if ($shippingRate !== false) {
            $shippingCost = Tools::convertPrice($shippingRate["carrier_cost"], Currency::getCurrencyInstance((int)$cart->id_currency));
       
            // Obtenemos el costo total del carrito y el peso total
            $total = $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING);
            $incrementoCoste = floatval(BBCarrierCarrier::getCarrierCostIncrement($this->id_carrier));

            $configuration = Configuration::getMultiple(array(
                        'PS_SHIPPING_FREE_PRICE',
                        'PS_SHIPPING_HANDLING',
                        'PS_SHIPPING_METHOD',
                        'PS_SHIPPING_FREE_WEIGHT'
            ));
            
            //Comprobamos que el envio es gratuito
            $freeFeesPrice = 0;
            
            if (isset($configuration['PS_SHIPPING_FREE_PRICE'])) {
                $freeFeesPrice = $configuration['PS_SHIPPING_FREE_PRICE'];
            }

            if ($total >= (float) ($freeFeesPrice) && (float) ($freeFeesPrice) > 0) {
                return 0;
            }

            // Comprobamos si hay incremento del envio en el modulo
            if ($incrementoCoste > 0) {
                $incrementoCoste = 1 + $incrementoCoste / 100;
                return $shippingCost * $incrementoCoste;
            }
        }
        
        return $shippingCost;
    }

    /**
     * Devuelve la tarifa del trasportista.
     * 
     * @param type $shippingOptions respuesta de la API con las tarifas disponibles
     * @param type $carrierExternalId el id externo del transportista
     * 
     * @return array|bool devuelve el array con los datos de la tarifa o false 
     *                      si existe una tarifa para este transportista
     */
    private function getShippingRate ($shippingOptions, $carrierExternalId)
    {
        if (!$shippingOptions || !$shippingOptions["shipping_costs"]) {
            return false;
        }
        
        foreach ($shippingOptions["shipping_costs"] as $shippingRate) {
            if ($carrierExternalId == $shippingRate["carrier_id"]) {
                return $shippingRate;
            }
        }

        return false;
    }
    
    /**
     * Devuelte las opciones de envío disponibles para el carrito.
     * 
     * @param type $cart el carrito
     * @param type $products listado de productos del carrito
     * 
     * @return array las opciones de envío de la API
     */
    private function getShippingOptions($cart, $products) 
    {
        /**
         * Guardamos los costes de envío de la API en la cache por cada carrito.
         */
        $cache_id = 'BBCARRIER_getShippingsOptions'
                . '_' . $cart->id 
                . '_' . $cart->id_address_delivery;

        if ($products) {
            foreach ($products as $product) {
                $cache_id .= '_' . $product['id_product']
                           . '_' . $product['id_product_attribute']
                           . '_' . $product['cart_quantity']; 
            }
        }

        if (Cache::isStored($cache_id)) {
            $shippingOptions = Cache::retrieve($cache_id);
        }
        else {
            $customerAddress = new Address((int)$cart->id_address_delivery);
            $customerAddressCountry = new Country($customerAddress->id_country);

            $apiCall = new BBCarrierAPI();
            $shippingOptions = $apiCall->getOrderShippingsByAPI(
                $customerAddressCountry->iso_code, 
                $customerAddress->postcode,
                $products
            );
            Cache::store($cache_id, $shippingOptions);
        }

        return $shippingOptions;
    }
}
