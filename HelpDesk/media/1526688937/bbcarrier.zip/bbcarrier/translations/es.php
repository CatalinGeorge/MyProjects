<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bbcarrier}prestashop>bbcarrier_d2126da975d5b9a5b846efaf57d3fd53'] = 'Configuración';
$_MODULE['<{bbcarrier}prestashop>bbcarrier_690ebfada52cc715651a1424b8a8366c'] = 'Escriba el porcentaje de incremento del coste de envío (ponga 0 para no aplicar incremento)';
$_MODULE['<{bbcarrier}prestashop>bbcarrier_cf565402d32b79d33f626252949a6941'] = 'Guardar configuración';
$_MODULE['<{bbcarrier}prestashop>bbcarrier_a45c947d87de07eb5613b88d83cbab28'] = 'Necesita configurar correctamente: El porcentaje de incremento del coste de envío';
