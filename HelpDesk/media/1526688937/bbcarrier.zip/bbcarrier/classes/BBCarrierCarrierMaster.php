<?php

class BBCarrierCarrierMaster extends ObjectModel
{
    public $id;
    public $name;
    public $cost_increment;
    public $active;
    
    public static $moduleName = "bbcarrier";

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'bbcarrier_carrier_master',
        'primary' => 'id_bbcarrier_carrier_master',
        'fields' => array(
            'name' => array(
                'type' => self::TYPE_STRING, 
                'size' => 50,
                'required' => true,
            ),
            'cost_increment' => array(
                'type' => self::TYPE_FLOAT, 
                'validate' => 'isFloat'),
            'active' => array(
                'type' => self::TYPE_BOOL, 
                'validate' => 'isBool', 
                'required' => true
            ),
        )
    );
    
    public static function getActiveCarrierMasters ()
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE active = 1";

        $activeCarrierMasters = Db::getInstance()->executeS($sql);

        return $activeCarrierMasters;
    }
    
    public static function getCarrierMasters ()
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"];

        $carrierMasters = Db::getInstance()->executeS($sql);

        return $carrierMasters;
    }
    
    public static function carrierMasterExists ($idCarrierMaster)
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE " . self::$definition["primary"] . " = $idCarrierMaster";
        
        $result = Db::getInstance()->executeS($sql);
        
        return false !== $result && (is_array($result) && !empty($result));
    }
    
    public static function carrierMasterIsActive ($idCarrierMaster)
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE " . self::$definition["primary"] . " = $idCarrierMaster
                AND active = 1";
        
        $result = Db::getInstance()->executeS($sql);
        
        return false !== $result && (is_array($result) && !empty($result));
    }
    
    public static function disableMasterCarriers ($carrierMasterIds)
    {
        foreach ($carrierMasterIds as $carrierMasterId)
        {
            $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
            $carrierMaster->active = 0;
            $carrierMaster->update();
            
            $moduleCarriers = BBCarrierCarrier::getCarriersByCarrierMasterId($carrierMasterId, true);
            
            foreach ($moduleCarriers as $moduleCarrier)
            {
                BBCarrierCarrier::removeCarrier(
                    $moduleCarrier[BBCarrierCarrier::$definition["primary"]], 
                    $moduleCarrier["id_carrier"]
                );
            }
        }
    }
    
    public static function enableMasterCarriers ($carrierMasterIds)
    {
        foreach ($carrierMasterIds as $carrierMasterId)
        {
            $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
            $carrierMaster->active = 1;
            $carrierMaster->update();
            
            $moduleCarriers = BBCarrierCarrier::getCarriersByCarrierMasterId($carrierMasterId);

            foreach ($moduleCarriers as $moduleCarrier)
            {
                $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
                $carrierMaster->active = 1;
                $carrierMaster->update();
                
                BBCarrierCarrier::enableCarrier(
                    $moduleCarrier[BBCarrierCarrier::$definition["primary"]], 
                    $moduleCarrier["id_carrier"]
                );
            }
        }
    }
    
    public static function toggleStatusMasterCarrier ($carrierMasterId)
    {
        $carrierMaster = new BBCarrierCarrierMaster($carrierMasterId);
        
        switch ($carrierMaster->active) {
            case 0:
                return self::enableMasterCarriers(array($carrierMasterId));
            case 1:
                return self::disableMasterCarriers(array($carrierMasterId));
        }
    }
    

    
    public static function activateCarrierCountries ($carriers) 
    {
        $countriesData = "";
        
        foreach ($carriers as $carrier) {
            foreach ($carrier["countries"] as $country) {
                if (!isset($countriesData[$country])) {
                    $countriesData[] = $country;
                }
            }
        }
        
        $sql = "
            UPDATE ps_country 
            SET active = 1, contains_states = 0 
            WHERE iso_code IN (" . implode(",", $countriesData) . ");
            UPDATE ps_country 
            SET active = 1, contains_states = 1 
            WHERE iso_code IN ('ES','US');
        ";

        Db::getInstance()->execute($sql);
    }

    /**
     * Obtiene los transportistas de la API y si el transportista es nuevo, lo crea.
     * 
     * También comprueba si un transportista instalado ya no esté disponible en 
     * la API, y lo desactiva.
     * 
     * @return boolean true if API response was correct and carriers were installed,
     * false if API response was not correct.
     */
    public static function createCarriers ()
    {
        $carrierConfig = array();
        
        $apiCall = new BBCarrierAPI();
        $apiCarriers = $apiCall->getCarriersByAPI();
        
        if (!$apiCarriers) {
            return false;
        }
        
        foreach ($apiCarriers as $apiCarrier) {
            if (!BBCarrierCarrierMaster::carrierMasterExists($apiCarrier["carrier_master_id"])) {
                $carrierMaster = new BBCarrierCarrierMaster($apiCarrier["carrier_master_id"]);
                $carrierMaster->force_id = true;
                $carrierMaster->id = $apiCarrier["carrier_master_id"];
                $carrierMaster->name = $apiCarrier["carrier_master_name"];
                $carrierMaster->active = true;
                $carrierMaster->add();
            }
            
            if (!BBCarrierCarrierMaster::carrierMasterIsActive($apiCarrier["carrier_master_id"])) {
                continue;
            }
            
            if (BBCarrierCarrier::carrierExists($apiCarrier["external_id"])) {
                continue;
            }
            
            $delayLangs = array();
            $languages = Language::getLanguages(true);
            
            foreach ($languages as $language) {
                $delayLangs[$language['id_lang']] = strtr(
                    "Delivery " . $apiCarrier['delivery_type'], 
                    self::getDelayLang($language['iso_code'])
                );
            }
            
            //Creamos el array con los datos del transportista que se va a insertar                
            $carrierConfig = array(
                'name' => $apiCarrier['delivery_type'],
                'id_tax_rules_group' => 0,
                'active' => true,
                'deleted' => 0,
                'shipping_handling' => false,
                'range_behavior' => 0,
                'delay' => $delayLangs,
                'id_zone' => 1,
                'is_module' => true,
                'shipping_external' => true,
                'external_module_name' => self::$moduleName,
                'need_range' => true
            );

            //Insertamos en prestashop el transportista nuevo
            $createdCarrierId = self::installExternalCarrier($carrierConfig);
            
            $moduleCarrier = new BBCarrierCarrier();
            $moduleCarrier->force_id = true;
            $moduleCarrier->id = $apiCarrier["external_id"];
            $moduleCarrier->name = $apiCarrier["delivery_type"];
            $moduleCarrier->id_carrier = $createdCarrierId;
            $moduleCarrier->active = true;
            $moduleCarrier->id_bbcarrier_carrier_master = $apiCarrier["carrier_master_id"];
            $moduleCarrier->add();
        }
        
        BBCarrierCarrier::updateUnavailableCarriers($apiCarriers);
        //        self::activateCarrierCountries ($bbCarriers);
        
        return true;
    }    

    /**
     * Crea un transportista del módulo
     * 
     * @param type $config
     * @return boolean
     */
    public static function installExternalCarrier ($config)
    {        
        //Creamos el objeto carrier con los datos de configuracion
        $carrier = new Carrier();
        $carrier->name = $config['name'];
        $carrier->id_tax_rules_group = $config['id_tax_rules_group'];
        $carrier->id_zone = $config['id_zone'];
        $carrier->active = $config['active'];
        $carrier->deleted = $config['deleted'];
        $carrier->delay = $config['delay'];
        $carrier->shipping_handling = $config['shipping_handling'];
        $carrier->range_behavior = $config['range_behavior'];
        $carrier->is_module = $config['is_module'];
        $carrier->shipping_external = $config['shipping_external'];
        $carrier->external_module_name = $config['external_module_name'];
        $carrier->need_range = $config['need_range'];
        
        //Añadimos el transportista a prestashop
        if ($carrier->add()) {
            //Definimos los rangos de precios de manera que se dificil que se supere
            $groups = Group::getGroups(true);

            foreach ($groups as $group) {
                Db::getInstance()->insert('carrier_group', array('id_carrier' => (int) ($carrier->id), 'id_group' => (int) ($group['id_group'])));
            }
            
            $rangePrice = new RangePrice();
            $rangePrice->id_carrier = $carrier->id;
            $rangePrice->delimiter1 = '0';
            $rangePrice->delimiter2 = '1000000000';
            $rangePrice->add();
            //Definimos los rangos de peso de manera que se dificil que se supere
            $rangeWeight = new RangeWeight();
            $rangeWeight->id_carrier = $carrier->id;
            $rangeWeight->delimiter1 = '0';
            $rangeWeight->delimiter2 = '1000000000';
            $rangeWeight->add();

            //Obtenemos las tiendas
            $query = 'SELECT * FROM ' . _DB_PREFIX_ . 'carrier_shop where id_carrier = ' . ($carrier->id);
            $shops = Db::getInstance()->executeS($query);

            //Definimos el IVA para cada tienda que tendra el transportista
            //en este caso el mismo siempre
            foreach ($shops as $shop) {
                Db::getInstance()->insert('carrier_tax_rules_group_shop', array('id_carrier' => (int) ($carrier->id), 'id_tax_rules_group' => 1, 'id_shop' => $shop['id_shop']));
            }

            //Definimos las zonas de entrega del transportista
            $zones = Zone::getZones(true);

            foreach ($zones as $zone) {
                Db::getInstance()->insert('carrier_zone', array('id_carrier' => (int) ($carrier->id), 'id_zone' => (int) ($zone['id_zone'])));
                Db::getInstance()->insert('delivery', array('id_carrier' => (int) ($carrier->id), 'id_range_price' => (int) ($rangePrice->id), 'id_range_weight' => NULL, 'id_zone' => (int) ($zone['id_zone']), 'price' => '0'), true);
                Db::getInstance()->insert('delivery', array('id_carrier' => (int) ($carrier->id), 'id_range_price' => NULL, 'id_range_weight' => (int) ($rangeWeight->id), 'id_zone' => (int) ($zone['id_zone']), 'price' => '0'), true);
            }

            //Creamos la imagen del transportis generica
            if (!copy(_PS_MODULE_DIR_ . '/bbcarrier/trans_img.jpg', _PS_SHIP_IMG_DIR_ . '/' . (int) $carrier->id . '.jpg')) {
                return false;
            }

            // Return ID Carrier
            return (int) ($carrier->id);
        }

        return false;
    }

    /**
     * Actualiza los datos de los transportistas del modulo disponibles en la tienda
     * 
     * Comprueba si el modulo necesita actualizar los datos de los transportistas 
     * de la API y en caso afirmativo crea los transportistas nuevos y desactiva 
     * los transportistas que ya no estén disponibles.
     * 
     * @return boolean
     */
    public static function updateCarriersByAPI()
    {
        $minAccess = new DateTime("-1 week");
        
        if (Cache::isStored("BBCARRIER_LAST_API_UPDATE")) {
            $lastApiCarriersUpdate = new DateTime(Cache::retrieve("BBCARRIER_LAST_API_UPDATE"));
        } 
        else {
            $lastAPIUpdateValue = Configuration::get("BBCARRIER_LAST_API_UPDATE");
            Cache::store("BBCARRIER_LAST_API_UPDATE", $lastAPIUpdateValue);
            
            $lastApiCarriersUpdate = new DateTime($lastAPIUpdateValue);
        }
        
        if ($minAccess > $lastApiCarriersUpdate) {
            $lastApiCarriersUpdate = new DateTime("now");
            self::createCarriers();
            Configuration::updateValue('BBCARRIER_LAST_API_UPDATE', $lastApiCarriersUpdate->format("Y-m-d H:i:s"));
            Cache::store("BBCARRIER_LAST_API_UPDATE", $lastApiCarriersUpdate->format("Y-m-d H:i:s"));
            
            return true;
        }
        
        return false;
    }
    
    public static function getDelayLang ($isoCode) 
    {
        switch ($isoCode) { 
            case 'es':
                return array(
                    'days' => 'días',
                    'Delivery' => 'Entrega'
                );
            case 'en':
                return  array();
            case 'fr': 
                return array(
                    'days' => 'jours',
                    'Delivery' => 'Livraison'
                );
            case 'it': 
                return array(
                    'days' => 'giorni',
                    'Delivery' => 'Consegna'
                );
            default:
                return array();
        }
    }
}
