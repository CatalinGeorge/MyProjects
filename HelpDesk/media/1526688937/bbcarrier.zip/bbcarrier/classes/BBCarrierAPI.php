<?php

class BBCarrierAPI
{
    private $apiUrl = 'http://www.bigbuy.eu/service/carriers/';

    /**
     * Obtiene los datos de los transportistas disponibles en la API
     * 
     * @return array con los datos de los transportistas
     */
    public function getCarriersByAPI ()
    {
        // Initialize results
        $carriersData = array();

        // Get carriers from API
        $apiCarriers = $this->makeRequest("get");

        if (!$apiCarriers) {
            return;
        }
        
        /**
         * Create results array as Db results structure.
         */
        foreach ($apiCarriers as $apiCarrier) {
            $carrierType = $apiCarrier["carrier_name"] . " " . $apiCarrier["carrier_delay"];
            $carriersData[] = array(
                "delivery_type" => $carrierType,
                "external_id" => $apiCarrier["carrier_id"],
                "carrier_master_id" => $apiCarrier["carrier_master_id"],
                "carrier_master_name" => $apiCarrier["carrier_master_name"],
            );
        }

        return $carriersData;
    }
    
    /**
     * Hace una petición a la API y recoge los datos de envío.
     * 
     * @param type $isoCountry el iso_code del país de envío
     * @param type $postcode el código postal del país de envío
     * @param type $products listado de productos del carrito
     * 
     * @return array|null el array con los datos de envío o null en caso de estados erróneos
     */
    public function getOrderShippingsByAPI ($isoCountry, $postcode, $products)
    {
        $queryProducts = array();

        foreach ($products as $product) {
            $productSku = $this->removePrefix($product['reference']);
            $queryProducts["products[" . $productSku . "]"] = $product['cart_quantity'];
        }
        
        $requestParams = array_merge(
            array(
                'iso_country' => $isoCountry,
                'postcode' => $postcode,
            ),
            $queryProducts
        );
        
        $result = $this->makeRequest("costs", $requestParams);
        
        if (1 === $result["status"] || 2 === $result["status"]) {
            return $result;
        }
        
        return null;
    }
    
    private function removePrefix ($productReference) 
    {
        $productSku = $productReference;
        $skuPrefix = $this->getSkuPrefix ();
        
        if (substr($productReference, 0, strlen($skuPrefix)) === $skuPrefix) {
            $productSku = substr($productReference, strlen($skuPrefix));
        }
        
        return $productSku;
    }
    
	private function getSkuPrefix () 
	{
		$skuPrefix = Configuration::get('BBCARRIER_SKU_PREFIX');
		
		if (!$skuPrefix) {
			$skuPrefix = "bb_";
			Configuration::updateValue('BBCARRIER_SKU_PREFIX', $skuPrefix);
		}
		
		return $skuPrefix;
	}
	
    private function makeRequest ($apiCall, $params = array(), $language = "EN")
    {
        $queryParams = array_merge($params, array("language" => $language));
        $connection = curl_init();

        curl_setopt($connection, CURLOPT_URL, $this->apiUrl . $apiCall);
        curl_setopt($connection, CURLINFO_HEADER_OUT, true);
        curl_setopt($connection, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($connection, CURLOPT_ENCODING, "UTF-8");
        curl_setopt($connection, CURLOPT_POST, count($queryParams));
        curl_setopt($connection, CURLOPT_POSTFIELDS, http_build_query($queryParams));
        curl_setopt($connection, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($connection, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($connection, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($connection); // Send the Request
        $responseHttpCode = curl_getinfo($connection, CURLINFO_HTTP_CODE);

        if (!curl_errno($connection)) {
            if ($responseHttpCode >= 400 && $responseHttpCode < 500) {
                return array(
                    "status" => "$responseHttpCode",
                    "msg" => "Client error $responseHttpCode - Failed sending $apiCall request",
                );
            }
            else if ($responseHttpCode >= 500 && $responseHttpCode < 600) {
                return array(
                    "status" => "$responseHttpCode",
                    "msg" => "Server error $responseHttpCode - API server failed to respond.",
                );
            }
        }

        curl_close($connection);
        
        return Tools::jsonDecode($response, true);
    }
    
}
