<?php

class BBCarrierCarrier extends ObjectModel
{
    public $id;
    public $name;
    public $id_carrier;
    public $id_bbcarrier_carrier_master;
    public $active;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'bbcarrier_carrier',
        'primary' => 'id_bbcarrier_carrier',
        'fields' => array(
            'name' => array(
                'type' => self::TYPE_STRING, 
                'size' => 250,
                'required' => true,
            ),
            'id_carrier' => array(
                'type' => self::TYPE_INT, 
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'id_bbcarrier_carrier_master' => array(
                'type' => self::TYPE_INT, 
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'active' => array(
                'type' => self::TYPE_BOOL,
                'validate' => 'isBool',
                'required' => true,
            ),
        )
    );
    
    public static function carrierExists ($idCarrier)
    {
        $sql = "SELECT * 
                FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
                WHERE " . self::$definition["primary"] . " = $idCarrier";
            
        $result = Db::getInstance()->executeS($sql);
                                       
        return false !== $result && (is_array($result) && !empty($result));                        
    }
    
    public static function getActiveCarriers ()
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE active = 1";

        $activeCarriers = Db::getInstance()->executeS($sql);

        return $activeCarriers;
    }
    
    public static function getCarriersByCarrierMasterId ($carrierMasterId, $onlyActive = false)
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE id_bbcarrier_carrier_master = $carrierMasterId";

        if ($onlyActive) {
            $sql .= " AND active = 1;";
        }
            
        $carriers = Db::getInstance()->executeS($sql);

        return $carriers;
    }
    
    public static function getCarriers ()
    {
        $sql = "SELECT * 
            FROM " . _DB_PREFIX_ . self::$definition["table"];

        $carriers = Db::getInstance()->executeS($sql);

        return $carriers;
    }
    public static function getCarrierByCarrierId ($carrierId) 
    {
        $sql = "SELECT *
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " 
            WHERE id_carrier = $carrierId";

        $carrier = Db::getInstance()->executeS($sql);
        
        foreach ($carrier as $result) {
            return $result;
        }
    }
    
    public static function getCarrierCostIncrement($carrierId)
    {
        $sql = "SELECT bcm.cost_increment as cost_increment 
            FROM " . _DB_PREFIX_ . self::$definition["table"] . " bc
            INNER JOIN " . _DB_PREFIX_ . BBCarrierCarrierMaster::$definition["table"] . " bcm   
                ON bc.id_bbcarrier_carrier_master = bcm.id_bbcarrier_carrier_master 
            WHERE bc.id_carrier = $carrierId";

        $costIncrement = Db::getInstance()->executeS($sql);

        foreach ($costIncrement as $result) {
            return $result["cost_increment"];
        }
    }
    
    /**
     * Desactiva el carrier del moduó con id $carrierId.
     * 
     * @param type $moduleCarrierId
     * @param type $carrierId
     * @return boolean
     */
    public static function enableCarrier ($moduleCarrierId, $carrierId)
    {
        $carrier = new Carrier((int) $carrierId);
        $carrier->active = true;
        $carrier->deleted = false;
        
        if (!$carrier->update()) {
            return false;
        }
        
        $moduleCarrier = new BBCarrierCarrier((int) $moduleCarrierId);
        $moduleCarrier->active = true;
        
        if (!$moduleCarrier->update()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Desactiva los carriers del módulo y borra los datos de configuración.
     * 
     * Si uno de los carriers del módulo se ha establecido como carrier por defecto, 
     * asigna uno de los carriers disponibles como carrier por defecto de la tienda.
     */
    public static function removeCarriers () 
    {
        $cacheId = "PS_CARRIER_DEFAULT";
        $defaultCarrierId = null;
        $resetDefaultCarrier = false;
        $moduleCarriers = BBCarrierCarrier::getCarriers();
        
        //Desinstalamos todos los transportistas creados por el modulo
        foreach ($moduleCarriers as $moduleCarrier) {
            $moduleCarrierId = $moduleCarrier["id_bbcarrier_carrier"];
            $carrierId = $moduleCarrier["id_carrier"];
            
            if (!$defaultCarrierId && Cache::isStored($cacheId)) {
                $defaultCarrierId = Cache::retrieve($cacheId);
            }
            else if (!$defaultCarrierId) {
                $defaultCarrierId = Configuration::get('PS_CARRIER_DEFAULT');
                Cache::store($cacheId, $defaultCarrierId);
            }

            if (self::removeCarrier($moduleCarrierId, $carrierId)
                && ($defaultCarrierId == $carrierId) 
                && !$resetDefaultCarrier) {
                $resetDefaultCarrier = true;
            }                    
        }

        if ($resetDefaultCarrier) {
            self::resetDefaultCarrier();
        }
    }
        
    /**
     * Desactiva el carrier del moduó con id $carrierId.
     * 
     * @param type $moduleCarrierId
     * @param type $carrierId
     * @return boolean
     */
    public static function removeCarrier ($moduleCarrierId, $carrierId)
    {
        $carrier = new Carrier((int) $carrierId);
        $carrier->active = false;
        $carrier->deleted = true;

        if (!$carrier->update()) {
            return false;
        }
        
        $moduleCarrier = new BBCarrierCarrier((int) $moduleCarrierId);
        $moduleCarrier->active = false;
        
        if (!$moduleCarrier->update()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Resetea el carrier por defecto de la tienda.
     * 
     * @global type $cookie
     */
    public static function resetDefaultCarrier ()
    {
        global $cookie;
        
        $cacheId = "PS_CARRIER_DEFAULT";
        $availableCarriers = Carrier::getCarriers($cookie->id_lang, true, false, false, NULL, PS_CARRIERS_AND_CARRIER_MODULES_NEED_RANGE);

        foreach ($availableCarriers as $availableCarrier) {
            if ($availableCarrier['active'] && !$availableCarrier['deleted']) {
                Configuration::updateValue('PS_CARRIER_DEFAULT', $availableCarrier['id_carrier']);
                Cache::store($cacheId, $availableCarrier['id_carrier']);
                break;
            }
        }
    }
    
    
    /**
     * Desactiva los transportistas que ya no estén disponibles en la API
     * 
     * @param type $apiCarriers los transportistas disponibles en la API
     */
    public static function updateUnavailableCarriers ($apiCarriers)
    {
        $cacheId = "PS_CARRIER_DEFAULT";
        $defaultCarrierId = null;
        $resetDefaultCarrier = false;
        $moduleCarriers = BBCarrierCarrier::getActiveCarriers();
        
        foreach ($moduleCarriers as $moduleCarrier) {
            $moduleCarrierId = $moduleCarrier[BBCarrierCarrier::$definition["primary"]];
            $carrierId = $moduleCarrier["id_carrier"];
            $activeInAPI = false;
            
            foreach ($apiCarriers as $apiCarrier) {
                if ($apiCarrier['external_id'] == $moduleCarrierId) {
                    $activeInAPI = true;
                    break;
                }
            }
            
            if ($activeInAPI) {
                continue;
            }
            
            if (!$defaultCarrierId && Cache::isStored($cacheId)) {
                $defaultCarrierId = Cache::retrieve($cacheId);
            }
            else if (!$defaultCarrierId) {
                $defaultCarrierId = Configuration::get('PS_CARRIER_DEFAULT');
                Cache::store($cacheId, $defaultCarrierId);
            }

            if (self::removeCarrier($moduleCarrierId, $carrierId)
                && ($defaultCarrierId == $carrierId) 
                && !$resetDefaultCarrier) {
                $resetDefaultCarrier = true;
            }
        }
        
        if ($resetDefaultCarrier) {
            self::resetDefaultCarrier();
        }
    }
    
}
