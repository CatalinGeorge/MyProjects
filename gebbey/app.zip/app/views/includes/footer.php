<script src="https://www.paypalobjects.com/api/checkout.js"></script>

</body>
</html>
