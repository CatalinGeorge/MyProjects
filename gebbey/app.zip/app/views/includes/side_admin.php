<!--Page-->
  <div class="admin-page">

    <!--Left Sidebar-->
    <div class="col-md-2 hidden-xs admin-sidebar">

      <a href="<?php echo base_url(); ?>admin/">Home</a>
      <a href="<?php echo base_url(); ?>admin/go/locations">Locations</a>
      <a href="<?php echo base_url(); ?>admin/go/listings">Listings</a>
      <a href="<?php echo base_url(); ?>admin/go/categories">Categories</a>
      <a href="<?php echo base_url(); ?>admin/go/automobile">Automobile</a>
      <a href="<?php echo base_url(); ?>admin/go/users">Users</a>
      <a href="<?php echo base_url(); ?>admin/go/advertisers">Advertisers</a>
      <a href="<?php echo base_url(); ?>admin/go/advertisements">Advertisements</a>
      <a href="<?php echo base_url(); ?>admin/go/comments">Comments</a>
      <a href="<?php echo base_url(); ?>admin/go/settings">Settings</a>

    </div><!--Left Sidebar-->

    <div class="col-md-10 col-md-offset-2 col-xs-12 admin-content">
