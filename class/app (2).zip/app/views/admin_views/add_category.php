<!-- AngularJS -->
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

<!-- Angular Sortable -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-tree/2.22.6/angular-ui-tree.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-tree/2.22.6/angular-ui-tree.min.js"></script>

<script>
(function () {
  'use strict';
angular.module('myApp', ['ui.tree'])

 .controller('gogu', ['$scope', '$http', function ($scope, $http) {

   $scope.remove = function (scope) {
           scope.remove();
         };

         $scope.toggle = function (scope) {
           scope.toggle();
         };

         $scope.moveLastToTheBeginning = function () {
           var a = $scope.data.pop();
           $scope.data.splice(0, 0, a);
         };

         $scope.newSubItem = function (scope) {
           var nodeData = scope.$modelValue;
           nodeData.nodes.push({
             id: nodeData.id * 10 + nodeData.nodes.length,
             title: nodeData.title + '.' + (nodeData.nodes.length + 1),
             nodes: []
           });
         };

         $scope.collapseAll = function () {
           $scope.$broadcast('angular-ui-tree:collapse-all');
         };

         $scope.expandAll = function () {
           $scope.$broadcast('angular-ui-tree:expand-all');
         };





   $http.get("http://ccs.pssthemes.com/admin/categories/get_cat_test")
    .then(function(response) {
      $scope.data = JSON.parse(response.data.json);
        console.log($scope.data);

    });

      $scope.save = function() {
        console.log($scope.data);

        $http({
      method: 'GET',
      url: 'http://ccs.pssthemes.com/admin/categories/update_cat_test',
      params: {
        json: $scope.data,
      },
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      }
      }).then(function(res){
        console.log(res);
        location.reload();
      }),function(error){
      };
      }


      $scope.edit = function(cat) {
        console.log(cat);
      }


    }]);
}());
</script>

<div ng-app="myApp" ng-controller="gogu">

  <!-- Nested node template -->
  <script type="text/ng-template" id="nodes_renderer.html">
    <div ui-tree-handle class="tree-node tree-node-content">
      <a class="btn btn-success btn-xs pull-right" data-nodrag ng-click="edit(this)"><span class="glyphicon glyphicon-edit"></span></a>
      <a class="btn btn-success btn-xs" ng-if="node.nodes && node.nodes.length > 0" data-nodrag ng-click="toggle(this)"><span
          class="glyphicon"
          ng-class="{
            'glyphicon-chevron-right': collapsed,
            'glyphicon-chevron-down': !collapsed
          }"></span></a>
      {{node.title}}
      <a class="pull-right btn btn-danger btn-xs" data-nodrag ng-click="remove(this)"><span
          class="glyphicon glyphicon-remove"></span></a>
      <a class="pull-right btn btn-primary btn-xs" data-nodrag ng-click="newSubItem(this)" style="margin-right: 8px;"><span
          class="glyphicon glyphicon-plus"></span></a>
    </div>
    <ol ui-tree-nodes="" ng-model="node.nodes" ng-class="{hidden: collapsed}">
      <li ng-repeat="node in node.nodes" ui-tree-node ng-include="'nodes_renderer.html'">
      </li>
    </ol>
  </script>

  <div class="row">
    <div class="col-sm-12">
      <h3>Basic Example</h3>

      <button ng-click="expandAll()">Expand all</button>
      <button ng-click="collapseAll()">Collapse all</button>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6">
      <div ui-tree id="tree-root">
        <ol ui-tree-nodes ng-model="data">
          <li ng-repeat="node in data" ui-tree-node ng-include="'nodes_renderer.html'"></li>
        </ol>
      </div>
    </div>

    <div class="col-sm-6">
      <div class="info">
        {{info}}
      </div>
      <pre class="code">{{ data | json }}</pre>
    </div>
  </div>

<a ng-click="save()">Save</a>


</div>
