<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories_model extends CI_Model {
    public function __construct()
    {
        $this->load->database();
        $this->load->helper('url');

    }

    public function get_categories()
          {
            $this->db->from('categories');
            $query = $this->db->get();
              if($query->num_rows() > 0){
                  $result = $query->result_array();
                  return $result;
              }else{
                  return false;
              }
          }

  public function add_category()
            {
              $data=array(
                'cat_name' =>$this->input->post('category'),
              );
              return $this->db->insert('categories',$data);
            }


            public function get_cat_test() {
              $this->db->from('cat_test');
              $query = $this->db->get();
                if($query->num_rows() > 0){
                    $result = $query->row_array();
                    return $result;
                }else{
                    return false;
                }
            }

            public function update_cat_test($json) {
              $data = array(
                'json' => $json,
            );
            $this->db->update('cat_test', $data, array('id' => '1'));
              }






}
