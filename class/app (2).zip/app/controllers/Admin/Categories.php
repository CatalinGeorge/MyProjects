<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {

	public function __construct()
			 {
							 parent::__construct();
							 $this->load->model('Admin_model/categories_model', 'admin_categories');
							// $this->load->model('home_model');
							 $this->load->helper('url_helper');
							 $this->load->library('session');
							 $this->load->library('form_validation');
							 $this->load->helper('date');
			         $this->load->helper('url');
			         $this->load->library('image_lib');
			 }


    public function index()
    {
			$data['categories'] = $this->admin_categories->get_categories();
			$this->load->view('admin_views/includes/head');
      $this->load->view('admin_views/add_category', $data);
			$this->load->view('admin_views/includes/footer');
    }

    public function add_category()
    {
      $this->categories_model->add_category();
    }

		public function get_cat_test() {
			$plm = $this->admin_categories->get_cat_test();
			echo json_encode($plm);
		}

		public function update_cat_test() {
			$json = '['.$_GET['json'].']';
			$plm = $this->admin_categories->update_cat_test($json);
		}







}
