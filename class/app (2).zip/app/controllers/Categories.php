<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {
    public function __construct()
    {
        parent::__construct();

        //load model
        $this->load->model('categories_model');
        $this->load->model('home_model');

        //load libraries
        $this->load->library('session');
        $this->load->helper('date');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('user_agent');
        $this->load->helper('directory');


    }

  public function single_category($id)
  {
    $data['user'] = $this->session->user;
    $data['products'] = $this->categories_model->get_products($id);
    $data['categories'] = $this->home_model->get_categories();

    $this->load->view('categories_view', $data);
  }

  public function search()
  {
    $data['user'] = $this->session->user;
    $data['categories'] = $this->home_model->get_categories();
    $data['products'] = $this->categories_model->search();

    $this->load->view('categories_view',$data);
  }










}
