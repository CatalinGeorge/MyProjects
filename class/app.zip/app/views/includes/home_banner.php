<div class="row ui-gradient-light-blue m-t-30">
  <div class="container">
    <div class="col-md-7 p-b-50">
      <h1 class="min-text cap lh-60 fw-900 fs-48 p-t-50 p-l-50">powerful features <br> for your entertaiment</h1>
      <p class="cap fs-18 text-gray p-l-50 p-b-20">Powerful six core processor packed <br> into a slim design and <br> a 4k display.</p>
      <div class="btn-outline-b m-l-50 m-t-50">browse now <img src="<?php echo base_url(); ?>assets/img/icons/right-filled.png"></div>
    </div>
    <div class="col-md-4 col-md-offset-1">
      <img src="<?php echo base_url(); ?>assets/img/banner-img.png" width="100%" style="margin-top:-50px; -webkit-transform: scaleX(-1) !important; transform: scaleX(-1) !important;">
    </div>
  </div>
</div>
