

  <!-- Top Menu -->
  <div class="container p-t-b-10 border-bottom ">
    <div class="row">
      <div class="col-md-2 p-l-0">
        <h3 class="m-0 letter-spacing3 fw-900 up"><a href="<?php echo base_url(); ?>" >ccs</a><br><p class="cap fs-11 fw-100">Complete Classifieds Solution</p></h3>
      </div>
      <div class="col-md-6 p-t-10">
        <a class="text-dark up fw-700 fs-14 no-decoration p-l-r-20" href="<?php echo base_url(); ?>super_deals">super deals</a>
        <a class="text-blue up fw-700 fs-14 no-decoration p-l-r-20" href="#">auctions</a>
        <a class="text-dark up fw-700 fs-14 no-decoration p-l-r-20" href="#">sale</a>
        <a class="text-dark up fw-700 fs-14 no-decoration p-l-r-20" href="<?php echo base_url(); ?>user_profile">account</a>
      </div>
      <div class="col-md-4 text-right p-t-10">
            <a href="#" class="fs-12 text-gray cap no-decoration p-l-r-10">About us</a>
            <a href="#" class="fs-12 text-gray cap no-decoration p-l-r-10">Terms & Conditions</a>
            <a href="#" class="fs-12 text-gray cap no-decoration p-l-r-10">Get in touch</a>
      </div>
    </div>
  </div>
