<?php
class Categories_model extends CI_Model {

  public function __construct()
  {
          $this->load->database();
  }


  public function get_products($id)
      {
        $query = $this->db->get_where('products', array('pr_category' => $id));
        return $query->result_array();
      }

  public function search()
      {
            $this->db->like('pr_name',$this->input->post('search'));
            $query = $this->db->get('products');
            return $query->result_array();
      }













}
