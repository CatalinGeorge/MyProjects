<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
        {
                parent::__construct();
                $this->load->model('home_model');
								$this->load->model('single_model');
								$this->load->helper('url_helper');
								$this->load->library('session');
								$this->load->helper('directory');
								$this->load->library('form_validation');

        }

	public function index()
	{
		$data['products'] = $this->home_model->get_products();
		$data['categories'] = $this->home_model->get_categories();

		$_SESSION['r_w'] = $recently_viewed;
		 //$recently_viewed = $_SESSION['r_w'];
		$data['recently_viewed'] = $this->single_model->get_recently_viewed($recently_viewed);
		$data['user'] = $this->session->user;
		//$currentURL = current_url();
		//echo $currentURL;



		$this->load->view('home_view', $data);
	}

	public function search_category()
	{
		$data['user'] = $this->session->user;
		$data['categories'] = $this->home_model->get_categories();
		$data['products'] = $this->home_model->search_category();

		$this->load->view('categories_view',$data);
	}






}
