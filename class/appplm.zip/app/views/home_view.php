<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('includes/head'); ?>
<?php $this->load->view('includes/top_menu'); ?>
<?php $this->load->view('includes/header_big'); ?>
<?php $this->load->view('includes/home_banner'); ?>
<?php $this->load->view('includes/featured_top_best_home'); ?>
<?php $this->load->view('includes/recently_viewed'); ?>
<?php $this->load->view('includes/newsletter'); ?>
<?php $this->load->view('includes/footer'); ?>
