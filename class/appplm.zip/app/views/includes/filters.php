<div ng-controller="getSubcategories" ng-init="getSubcategoriesInit(<?php echo $main; ?>)">

  <!-- Nested node template -->
  <script type="text/ng-template" id="nodes_renderer.html">
    <div class="tree-node tree-node-content">

      {{node.title}}
    
    </div>
    <ol ui-tree-nodes="" ng-model="node.nodes" ng-class="{hidden: collapsed}">
      <li ng-repeat="node in node.nodes" ui-tree-node ng-include="'nodes_renderer.html'">
      </li>
    </ol>
  </script>


  <div class="row">
    <div class="col-sm-6">
      <div ui-tree id="tree-root">
        <ol ui-tree-nodes ng-model="data">
          <li ng-repeat="node in data" ui-tree-node ng-include="'nodes_renderer.html'"></li>
        </ol>
      </div>
    </div>

<div class="bg-light p-t-b-30">
  <div class="container">
    <div class="col-md-8 col-md-offset-2">

      <div class="row">
          <div class="col-md-4">
            <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
              <option value="volvo">Name</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
            </select>
          </div>
          <div class="col-md-4">
            <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
              <option value="volvo">City</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
            </select>
          </div>
          <div class="col-md-4">
            <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
              <option value="volvo">Category</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
              <option value="saab">Saab</option>
              <option value="mercedes">Mercedes</option>
              <option value="audi">Audi</option>
            </select>
          </div>
      </div>

      <div class="row">
        <div class="col-md-3">
          <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
            <option value="volvo">Type</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
          </select>
        </div>
        <div class="col-md-3">
          <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
            <option value="volvo">Year</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
          </select>
        </div>
        <div class="col-md-3">
          <select class="p-t-b-10 no-border full-width p-l-r-10 text-gray m-b-20">
            <option value="volvo">Price</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
          </select>
        </div>
        <div class="col-md-3">
          <div class="btn-outline-b block center">show results</div>
        </div>
      </div>

    </div><!-- end col -->
  </div><!-- end container -->
</div>
</div>
