<div class="col-md-3 border-left">
  <h5 class="text-gray">Recently Viewed Products</h5>
  <div class="row">
    <div class="col-md-12 p-t-b-20 round-small border-bottom2">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod2.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>

    <div class="col-md-12 p-t-b-20 round-small border-bottom2">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod3.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>

    <div class="col-md-12 p-t-b-20 round-small">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod1.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>
  </div>

  <h5 class="text-gray p-t-30">Recently Viewed Products</h5>
  <div class="row">
    <div class="col-md-12 p-t-b-20 round-small border-bottom2">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod4.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>
    <div class="col-md-12 p-t-b-20 round-small border-bottom2">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod2.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>
    <div class="col-md-12 p-t-b-20 round-small">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo base_url(); ?>assets/img/prod3.jpg" alt="1" width="100%">
        </div>
        <div class="col-md-9">
          <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
        </div>
      </div>
    </div>
  </div>
</div><!-- end right col -->

</div><!-- end row -->
</div><!-- end container -->


</body>
</html>
