<div class="container">
  <div class="inline m-t-b-20 round-small p-10">
    <div class="inline">
        <h4 class="cap p-l-r-10 m-0 text-gray">Top categories all time</h4>
    </div>
  </div>
</div>

<!-- Top categories -->
<div class="container p-b-50">
  <div class="row">
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod1.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod2.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod3.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod4.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod5.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
    <div class="col-md-2 center border-right box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod6.jpg" alt="1" width="100%">
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate</p>
    </div>
  </div>
</div>
