footer customer
