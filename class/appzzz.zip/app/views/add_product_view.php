<?php $this->load->view('includes/head'); ?>
<?php $this->load->view('includes/top_menu'); ?>
<?php $this->load->view('includes/header_big'); ?>
<?php $this->load->view('includes/add_product_form'); ?>
<?php $this->load->view('includes/sidebar'); ?>
