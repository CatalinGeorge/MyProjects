<?php $this->load->view('includes/head'); ?>
<?php $this->load->view('includes/header_compact'); ?>
<?php $this->load->view('includes/filters'); ?>
<?php $this->load->view('includes/filters_search_results'); ?>
