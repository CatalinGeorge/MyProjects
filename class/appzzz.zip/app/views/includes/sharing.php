<div class="">
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/facebook2.png"></div>
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/instagram-new.png"></div>
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/facebook-messenger.png"></div>
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/share.png"></div>
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/instagram2.png"></div>
    <div  class="box-effect inline round m-b-10"><img class="p-10" src="<?php echo base_url(); ?>assets/img/icons/twitter.png"></div>
</div>
</div>
</div>
</div>
