<div class="container p-t-b-50">
  <div class="row">
    <div class="col-md-5">

      <!-- Slider main container -->
      <div class="swiper-container">
          <div class="swiper-wrapper">
            <?php
 //load directory helper
$dir = 'media/'.$product["pr_media"].'/'; // Your Path to folder
$map = directory_map($dir); /* This function reads the directory path specified in the first parameter and builds an array representation of it and all its contained files. */

foreach ($map as $k) {?>
              <div class="swiper-slide" style="background:url(<?php echo base_url($dir)."/".$k;?>)no-repeat center center;background-size:cover;width:100%;"></div>
              <?php } ?>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-prev"><img src="<?php echo base_url(); ?>assets/img/icons/back-filled.png"></div>
          <div class="swiper-button-next"><img src="<?php echo base_url(); ?>assets/img/icons/forward-filled.png"></div>
          <div class="swiper-scrollbar"></div>

      </div>
      <!-- End Slider main container -->

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.2.6/js/swiper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/swiper.js"></script>
