<div class="container">
  <div class="inline m-t-b-20 round-small p-10">
    <div class="inline">
        <h4 class="cap p-l-r-10 m-0 text-gray">Best rated sellers this week</h4>
    </div>
  </div>
</div>

<!-- Top users -->
<div class="container p-b-50">
  <div class="row">
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/men/1.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/women/2.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/women/3.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/men/4.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/men/5.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
    <div class="col-md-2 center p-t-b-20">
      <img src="https://randomuser.me/api/portraits/women/6.jpg" alt="1" width="70" height="70" class="round">
      <p class="text-gray m-t-10 m-b-0">Michael Raims</p>
      <p class="text-gray fs-12 m-t-0">180 reviews | 7 products</p>
      <div>
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
        <img src="<?php echo base_url(); ?>assets/img/icons/star.png">
      </div>
    </div>
  </div>
</div>
