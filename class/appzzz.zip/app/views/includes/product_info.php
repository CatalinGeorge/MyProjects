<div class="col-md-6 p-t-b-10 p-l-r-20 border-right">
  <div class="row">
    <div class="col-md-2">
      <div class="v-center">
      <a href="<?php echo base_url(); ?>profile/provider_profile/<?php echo $product['pr_user']; ?>">  <img src="<?php echo base_url(); ?>media/profile/<?php echo $product['us_id']; ?>/<?php echo $product['us_avatar']; ?>" alt="1" width="25" height="25" class="round">
        <p class="text-gray m-b-0 p-l-10 fs-10 m-t--10"><?php echo $product['us_username']; ?>
          <div class="absolute p-t-10 p-l-35">
            <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png" width="5">
            <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png" width="5">
            <img src="<?php echo base_url(); ?>assets/img/icons/star-filled.png" width="5">
            <img src="<?php echo base_url(); ?>assets/img/icons/star.png" width="5">
            <img src="<?php echo base_url(); ?>assets/img/icons/star.png" width="5">
          </div></a>
        </p>
      </div>
    </div>
    <div class="col-md-8">
      <h3 class="m-t-0"><?php echo $product['pr_name']; ?></h3>
    </div>
    <div class="col-md-2">
      <span class="fw-600 text-blue float-right fs-24">$<?php echo $product['pr_price']; ?></span>
    </div>
  </div>



  <hr>
    <p class="text-gray lh-30 m-t-b-20"><?php echo $product['pr_description']; ?></p>


</div>
