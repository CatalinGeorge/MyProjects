<div class="container">
  <div class="inline m-t-b-20 round-small p-10">
    <div class="inline border-right">
        <h4 class="cap p-l-r-10 m-0 text-gray">new arrivals</h4>
    </div>
    <div class="inline border-right">
        <h4 class="cap p-l-r-10 m-0 text-gray">on sale</h4>
    </div>
    <div class="inline">
        <h4 class="cap p-l-r-10 m-0 text-gray">best sellers</h4>
    </div>
  </div>
</div>

<!-- Shop -->
<div class="container">
  <div class="row p-b-50">
    <div class="col-md-2 border-right center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod1.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <a href="single-product.html"><div class="btn-outline-b2">details</div></a>
    </div>
    <div class="col-md-2 border-right center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod2.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <div class="btn-outline-b2">details</div>
    </div>
    <div class="col-md-2 border-right center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod3.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <div class="btn-outline-b2">details</div>
    </div>
    <div class="col-md-2 border-right center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod4.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <div class="btn-outline-b2">details</div>
    </div>
    <div class="col-md-2 border-right center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod5.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <div class="btn-outline-b2">details</div>
    </div>
    <div class="col-md-2 center p-t-b-20 round-small box-effect">
      <img src="<?php echo base_url(); ?>assets/img/prod6.jpg" alt="1" width="100%">
      <h4 class="fw-600 text-blue">$435.45</h4>
      <p class="text-gray m-b-20 fs-12">Xtreme ultimate splashproof portable speaker</p>
      <div class="btn-outline-b2">details</div>
    </div>
  </div>
</div>
