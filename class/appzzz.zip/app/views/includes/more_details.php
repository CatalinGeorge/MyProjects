<div class="container">
  <div class="row">
    <div class="center">
      <button type="button" class="inside-icon-box2 bg-tr border round p-10 m-b-10 m-r-20 no-focus btn-filled" data-toggle="collapse" data-target="#demo">
        <span class="inside-icon2 "></span> &nbsp; View more details
      </button>
      <button type="button" class="inside-icon-box bg-tr border round p-10 m-b-10 m-r-20 no-focus btn-filled" data-toggle="collapse" data-target="#demo2">
        <span class="inside-icon "></span> &nbsp; Read comments
      </button>
    </div>

  <div id="demo" class="collapse">
    <div class="col-md-8 col-md-offset-2 m-t-20">
      <div class="row border-bottom">
        <div class="col-md-12 text-gray p-10 center fw-600">Hardware Specifications of <?php echo $product['pr_name']; ?></div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Processor</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_proc_type']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">RAM</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_ram_size']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Storage</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_hd_size']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Graphics</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray">1TB HDD</p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Display type</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_display_type']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Display size</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_display_size']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Operating System</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_os']; ?></p>
        </div>
      </div>

      <div class="row border-bottom">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Battery Life</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_baterry_life']; ?></p>
        </div>
      </div>

      <div class="row">
        <div class="col-md-3 p-0">
          <p class="m-0 p-10 text-gray fw-600">Weight</p>
        </div>
        <div class="col-md-9 p-0 border-left">
          <p class="m-0 p-10 text-gray"><?php echo $product['pr_weight']; ?></p>
        </div>
      </div>
    </div>
    </div>


    <div id="demo2" class="collapse">
    <div class="col-md-8 col-md-offset-2 m-t-20">
      <!--Comments -->
      <div class="border-gray round-small m-t-20">
        <?php echo form_open('single/create_comment'); ?>
      <div class="row p-b-10">
        <div class="col-md-11 p-0">
          <div class="form-elem-com">
            <input type="text" name="comment" placeholder="Leave your comment here..." class="full-width p-t-b-5 p-l-r-10">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>" />
            <input type="hidden" name="co_product_user" value="<?php echo $product['pr_user']; ?>"
          </div>
        </div>
        <div class="col-md-1 border-top2 border-bottom2 border-right2 p-0">
          <div class="p-l-10 bg-light">
           <input type="submit" style="position:absolute;width:40px;height:40px;opacity:0;"><img src="<?php echo base_url(); ?>assets/img/icons/long-arrow-right-filled.png" class="inline p-10 border-gray">
          </div>
        </div>
      </div>
    </form>
    <?php    if(!empty($comments)){ ?>
    <?php foreach($comments as $comment): ?>
        <div class="row p-t-20">
          <div class="col-md-1">
            <img src="https://randomuser.me/api/portraits/men/62.jpg" width="50" class="round">
          </div>
          <div class="col-md-11">
            <div class="p-l-r-10">
              <h5 class="fw-700 m-t-0"><?php echo $user['us_username']; ?>, <span class="fw-500 text-gray"><?php echo $comment['co_date']; ?></span> <span class="float-right text-gray fw-300 fs-12">&nbsp; <img src="<?php echo base_url(); ?>assets/img/icons/right2-filled.png" class="m-l-r-10"></span></h5>
              <p class="lh-20 text-gray"><?php echo $comment['co_comment']; ?> </p>
            </div>
          </div>
        </div>
        <hr>
      <?php endforeach; ?>
    <?php }else{ ?>
    <?php  } ?>
      </div>
    </div><!-- end first 6 column -->
  </div>

</div><!-- end row -->
</div><!-- end container -->
