<div class="bg-dark p-t-b-30">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <h3 class="m-t-0 m-b-30 letter-spacing3 fw-900 up text-white">ccs<br><p class="cap fs-11 fw-100">Complete Classifieds Solution</p></h3>
        <p class="m-b-5 cap text-white"><img src="<?php echo base_url(); ?>assets/img/icons/headset.png"> &nbsp; got questions?</p>
        <p class="m-b-5 cap text-white">call us: 800 00 00 00</p>
        <p class="m-b-5 cap text-white">address: </p>
        <p class="m-b-5 cap text-white">about us</p>
      </div>
      <div class="col-md-6">
        <h4 class="text-white up m-b-30">categories</h4>
        <div class="row">
          <div class="col-md-4">
            <a href="#" class="m-b-5 block text-white no-decoration cap">my account</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">whishlist</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">trades</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">offers</a>
            <a href="#" class="m-b-5 block text-white no-decoration up">faq's</a>
          </div>
          <div class="col-md-4">
            <a href="#" class="m-b-5 block text-white no-decoration cap">my account</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">whishlist</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">trades</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">offers</a>
            <a href="#" class="m-b-5 block text-white no-decoration up">faq's</a>
          </div>
          <div class="col-md-4">
            <a href="#" class="m-b-5 block text-white no-decoration cap">my account</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">whishlist</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">trades</a>
            <a href="#" class="m-b-5 block text-white no-decoration cap">offers</a>
            <a href="#" class="m-b-5 block text-white no-decoration up">faq's</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <h4 class="text-white up m-b-30">customer</h4>
        <a href="#" class="m-b-5 block text-white no-decoration cap">my account</a>
        <a href="#" class="m-b-5 block text-white no-decoration cap">whishlist</a>
        <a href="#" class="m-b-5 block text-white no-decoration cap">trades</a>
        <a href="#" class="m-b-5 block text-white no-decoration cap">offers</a>
        <a href="#" class="m-b-5 block text-white no-decoration cap">terms & conditions</a>
        <a href="#" class="m-b-5 block text-white no-decoration up">faq's</a>
      </div>
    </div>
  </div>
</div>

</body>
</html>
