

<div class="container p-t-b-10 border-bottom ">
  <div class="row">


    <?php  if($user){
        $this->db->from('favorite_products');
        $this->db->where('fp_product',$product['pr_id']);
        $this->db->where('fp_user',$user['us_id']);
        $query = $this->db->get();
              if($query->num_rows()==0)
              {
       ?>
<a href="<?php echo base_url(); ?>single/add_favorite/<?php echo $product['pr_id']; ?>/<?php echo $product['pr_user']; ?>">
<span class="p-l-r-10 p-t-b-5 border-right"><img class="p-t-b-10" src="<?php echo base_url(); ?>assets/img/icons/hearts.png"><span class="fs-12 m-l-r-5 text-gray bg-light2 round inline p-l-r-5">0</span></span></a>
<?php }
      }else { ?>
        <span class="p-l-r-10 p-t-b-5 border-right"><img class="p-t-b-10" src="<?php echo base_url(); ?>assets/img/icons/hearts.png"><span class="fs-12 m-l-r-5 text-gray bg-light2 round inline p-l-r-5">0</span></span>
          <?php } ?>

<span class="p-l-r-10 p-t-b-5 border-right modal-effect" data-toggle="modal" data-target="#myModal3"><img class="p-t-b-10" src="<?php echo base_url(); ?>assets/img/icons/synchronize.png"><span class="fs-12 m-l-r-5 text-gray bg-light2 round inline p-l-r-5">1</span></span>
<!-- Modal -->
<div class="modal fade" id="myModal3" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content text-left">
      <div class="modal-header no-border relative p-0" style="background: url(img/bg4.jpg)no-repeat center center;background-size:cover;width:100%;">
        <div class="absolute bg-white full op-8"></div>
        <div class="relative p-15">
          <button type="button" class="close" data-dismiss="modal"><img src="https://png.icons8.com/ios/20/000000/delete-sign-filled.png"></button>
          <h4 class="modal-title center">Select a product you want to offer:</h4>
        </div>
      </div>
      <div class="modal-body p-50 box-shadow2">

        <?php echo form_open('single/send_product_offer'); ?>
      <!--  <div class="dropdown">
          <button class="dropdown-toggle bg-tr no-border full-width text-left" type="button" data-toggle="dropdown">
            <img src="<?php echo base_url(); ?>assets/img/icons/menu.png">
            <span class="fs-14 cap">&nbsp; Select a product:</span>
          </button>

          <ul name="product"  class="dropdown-menu">
            <?php foreach ($products as $prd): ?>
              <li value="<?php echo $prd["pr_id"]; ?>"><?php echo $prd["pr_name"] ?> </li>
            <?php endforeach; ?>
          </ul>
        </div> -->

        <div class="form-elem mb20">
              <select class="p10" name="product">

                     <?php foreach ($products as $prd): ?>
                         <option value="<?php echo $prd["pr_id"]; ?>"><?php echo $prd["pr_name"] ?> </option>
                       <?php endforeach; ?>

             </select>
           </div>


        <div class="row v-center">
          <div class="col-md-3 p-0">
            <div class="btn-group no-round">
              <input type="hidden" value="<?php echo $product['pr_user']; ?>" name="po_to" >
              <input type="hidden" value="<?php echo $product['pr_id']; ?>" name="prd" >
              <input name="val_type" value="0" type="radio" ><span class="p-l-r-5">+</span><br>
              <input name="val_type" type="radio" value="1" ><span class="p-l-r-5">-</span>
            </div>
          </div>
          <div class="col-md-9 p-0">
            <input type="text" name="value" placeholder="$" class="border full-width m-t-b-20 p-l-r-20 p-t-b-10">
          </div>
        </div>

      </div>
      <div class="modal-footer no-border">
        <input type="submit" value="ok" class="btn p-10 bg-light2 up" >
      </div>
      </form>
    </div>
  </div>
</div>
<span class="p-l-r-10 p-t-b-5 border-right modal-effect" data-toggle="modal" data-target="#myModal"><img class="p-t-b-10" src="<?php echo base_url(); ?>assets/img/icons/new-post.png"><span class="fs-12 m-l-r-5 text-gray bg-light2 round inline p-l-r-5">2</span></span>
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
      <?php echo form_open('single/send_message'); ?>
    <div class="modal-content text-left">
      <div class="modal-header no-border relative p-0" style="background: url(<?php echo base_url(); ?>assets/img/bg4.jpg)no-repeat center center;background-size:cover;width:100%;">
        <div class="absolute bg-white full op-8"></div>
        <div class="relative p-15">
          <button type="button" class="close" data-dismiss="modal"><img src="https://png.icons8.com/ios/20/000000/delete-sign-filled.png"></button>
          <h4 class="modal-title center">Write a private message!</h4>
        </div>
      </div>
      <div class="modal-body box-shadow2 p-20">
        <textarea rows="7" name="message" placeholder="Leave a message..." class="no-border no-resize full-width p-20"></textarea>
      </div>
      <div class="modal-footer no-border">
        <input type="hidden" value="<?php echo $product['pr_user']; ?>" name="to" >
        <input type="hidden" value="<?php echo $product['pr_id'] ?>" name="prd" >
        <input type="submit" value="ok" class="btn p-10 bg-light2 up" >
      </div>
    </div>
  </form>
  </div>
</div>
<span class="p-l-r-10 p-t-b-5 border-right modal-effect" data-toggle="modal" data-target="#myModal2"><img class="p-t-b-10" src="<?php echo base_url(); ?>assets/img/icons/law.png"><span class="fs-12 m-l-r-5 text-gray bg-light2 round inline p-l-r-5">0</span></span>
<!-- Modal -->
<div class="modal fade" id="myModal2" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <?php echo form_open('single/send_offer'); ?>
    <div class="modal-content text-left">
      <div class="modal-header no-border relative p-0" style="background: url(<?php echo base_url(); ?>assets/img/bg4.jpg)no-repeat center center;background-size:cover;width:100%;">
        <div class="absolute bg-white full op-8"></div>
        <div class="relative p-15">
          <button type="button" class="close" data-dismiss="modal"><img src="https://png.icons8.com/ios/20/000000/delete-sign-filled.png"></button>
          <h4 class="modal-title center">Make an offer!</h4>
        </div>
      </div>
      <div class="modal-body box-shadow2 p-50">
        <input type="hidden" value="<?php echo $product['pr_id'] ?>" name="prd" >
        <input type="hidden" value="<?php echo $product['pr_user'] ?>" name="to" >
        <input type="text" name="value" placeholder="$$$" class="border full-width p-l-20 p-t-b-10"/>
      </div>
      <div class="modal-footer no-border">
        <input type="submit" value="ok" class="btn p-10 bg-light2 up" >
      </div>
    </div>
  </form>
  </div>
</div>
</div>
</div>
